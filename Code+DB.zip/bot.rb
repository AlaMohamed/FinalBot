require 'sinatra' # Import af libraries
require 'json'
require 'sqlite3'

set :port, 5000 # Lytter til porten
enable :logging, :dump_errors, :raise_errors # Errors Checking

# Params Parser
before do
  @params = JSON.parse(request.body.read)
  # puts @params
end

# TRY: BOOKING ROOM NUMBER
post '/' do
  content_type :json

  if !@params.nil?
    if @params['action']['slug'] == 'bookingroom' 
      roombooking = "The room " + @params['roomnumber']['raw'] + " has been booked"
    end
  end

  {
    replies: [{ type: 'text', content: roombooking }],
    conversation: {
      memory: {
        key: 'value'
      }
    }
  }.to_json
end

# Check Booking Building and Room
post '/bookingroom' do

convsationmemory = @params['conversation']['memory']
memorybookingID = @params['conversation']['memory']['bookingid']

  if (convsationmemory && memorybookingID) then
     bookingid = @params['conversation']["memory"]['bookingid']['raw']
  else
     bookingid = nil
  end

  if bookingid.nil? 

    if(convsationmemory) then
       if(@params['conversation']['memory']['roomnumber']) then
	       roomnumber = @params['conversation']['memory']['roomnumber']['value']

         if(roomnumber)
	         buildingnumber = roomnumber.split(".")  
         end

       end
    end

    if (roomnumber && buildingnumber) then
    	  buildingexist = true

    	  # THESE CHECKS IF THE BUILDING EXIST
    	  begin
    	       db = SQLite3::Database.open "ProjectDB.db"
    	       stm = db.prepare "SELECT COUNT (building_number) FROM BUILDING INNER JOIN ROOMS ON rooms.building_id = building.building_id WHERE building.building_number = '#{buildingnumber[0]}' AND rooms.room_number = '#{buildingnumber[1]}'"

    	       rs = stm.execute
    	       buildingcount = rs.next

    	     if (buildingcount[0] == 0) then
    		       buildingexist = false
    	     end

    	  rescue SQLite3::Exception => e
    		 puts "Exception occurred"
         puts e
         
    	  ensure
    		 stm.close if stm
    		 db.close if db
        end
        # BUILDING AND ROOMNUMBER EXIST OR NOT
    	  if (buildingexist == true) then
    	      responsetext = "When do you want to book the room? Please give me a specific date. I will just check if the room is available."
    	  end
      else
         responsetext = "The building or roomnumber does not exist. Try another building or room." 
      end
  else
    # Update booking (building and room)
     if(@params['conversation']['memory']['roomnumber']) then
       roomnumber = @params['conversation']['memory']['roomnumber']['value']
       if(roomnumber) then
         buildingnumber = roomnumber.split(".") 
       end
     end

	   isUpdate = true

    	  begin
    	       db = SQLite3::Database.open "ProjectDB.db"
    	       stm = db.prepare "SELECT COUNT (building_number) FROM BUILDING INNER JOIN ROOMS ON rooms.building_id = building.building_id WHERE building.building_number = '#{buildingnumber[0]}' AND rooms.room_number = '#{buildingnumber[1]}' "
    	       rs = stm.execute
    	       buildingcount = rs.next

    	     if (buildingcount[0] == 0) then
      		     responsetext = "Building or Room does not exist."
               isUpdate == false
    	     end

    	  rescue SQLite3::Exception => e
    		    puts "Exception occurred"
    		    puts e
    	  ensure
    		    stm.close if stm
    		    db.close if db
    	  end
         # If building and roomnumber exist, user will be able to update booking
         if (isUpdate == true) then
    	     begin
            db = SQLite3::Database.open "ProjectDB.db"
            roomSelect = "SELECT room_id FROM ROOMS WHERE room_number = '#{buildingnumber[1]}'"

            stm = db.prepare(roomSelect)
            rs = stm.execute()
            room_id = rs.next

            if(room_id[0] == nil) then
                responsetext = "Your Booking with this room is already exist." 
       		  else

                updateBooking = "UPDATE BOOKING SET room_id = '#{room_id[0]}' WHERE booking_id = '#{bookingid}'"
                btstm = db.prepare(updateBooking)
                result = btstm.execute()
                booking = result.next
                responsetext = "You Room Booking is updated." 

            end
          rescue SQLite3::Exception => e
    		      puts "Exception occurred"
    		      puts e
    	    ensure
    	         stm.close if stm
               btstm.close if btstm
    		       db.close if db
    	     end
        else
    	     responsetext = "Room not available to book." 
        end
   end

     content_type :json
     {
       replies: [{ type: 'text', content: responsetext }],
       conversation: {
         memory: {
           'roomnumber': roomnumber
          }
       }
      }.to_json
end

# Booking on a Date
post '/bookingagreement' do

  convsationmemory = @params['conversation']['memory']
  memorybookingID = @params['conversation']['memory']['bookingid']

  if (convsationmemory && memorybookingID) then
   bookingid = @params['conversation']['memory']['bookingid']['raw'] # Booking ID is exist
  end

  modifyParams = @params['conversation']['memory']
  if bookingid.nil?

    if (modifyParams) then
       if (@params['conversation']['memory']['date']) then
  	     bookingdate = @params['conversation']['memory']['date']['raw']      
       end
       if (@params['conversation']['memory']['roomnumber']) then
         userroomnumber = @params['conversation']['memory']['roomnumber']    
       end
    end

    if (userroomnumber) then
      roomnumber = userroomnumber.split(".")            
    end
	  bookingConfirmed = true
	  bookingResponse = "Something is wrong. Try to write the date correct." 

    if (roomnumber && bookingdate) then
    	  begin

    	    db = SQLite3::Database.open "ProjectDB.db"
    	    sqlJoin = "SELECT room_id FROM ROOMS WHERE room_number = '#{roomnumber[1]}'" 
    	    stm = db.prepare(sqlJoin)

    	    rs = stm.execute()
    	    array_room_id = rs.next

    	    if (array_room_id == nil) then
              bookingResponse = "Room does not exist with this room number. Please try another room number" 
    	    else

             dateCounter = "SELECT date FROM BOOKING WHERE date = '#{bookingdate}' AND room_id = #{array_room_id[0]}"
    	       datestm = db.prepare(dateCounter)
    	       result = datestm.execute()
    	       dbDate = result.next

    	       if (dbDate != nil && bookingdate == dbDate[0]) then
    	          bookingResponse = "Room is not available for this specific date."
    	       else
        	       begin
            			 strSql = "INSERT INTO BOOKING (room_id, date) VALUES ('#{array_room_id[0]}', '#{bookingdate}')"

                   stmCreate = db.prepare(strSql)
            			 res = stmCreate.execute()

                   bookingRs = res.next
            			 bookingID = db.last_insert_row_id
                   modifyParams = {}
                   bookingResponse = "Your booking is confirmed! :) \nYour bookingID is #{bookingID}"

                 rescue
          		     bookingResponse = "Error in response"
                 end
    	       end

    	    end
    	  rescue SQLite3::Exception => e
    	    puts "Exception occurred"
    	    puts e
    	  ensure
    	    stm.close if stm
     	    datestm.close if datestm
          stmCreate.close if stmCreate
    	    db.close if db
    	  end
    end

     content_type :json
    {
      replies: [{ type: 'text', content: bookingResponse }],
      conversation: {
        memory: modifyParams
      }
    }.to_json

  else
       begin
           bookingdate = nil
           if( @params['conversation']['memory'] && @params['conversation']['memory']['date']) then
             bookingdate = @params['conversation']['memory']['date']['raw']
           end

           if(bookingdate) then
             db = SQLite3::Database.open "ProjectDB.db"
             bookingSelect = "SELECT booking_id FROM BOOKING WHERE booking_id = '#{bookingid}' AND date = '#{bookingdate}'"
             stm = db.prepare(bookingSelect)
             rs = stm.execute()
             booking_room_id = rs.next

             if (booking_room_id == nil) then

                updateBooking = "UPDATE BOOKING SET date = '#{bookingdate}' WHERE booking_id = '#{bookingid}'"
                updatestm = db.prepare(updateBooking)

  	            results = updatestm.execute()
        	      update_booking = results.next
                modifyParams = {}

                bookingResponse = "Your Booking is updated. Thank you."
             else
   	           bookingResponse = "Room is already booked on this date. Please select another date"
             end

           else
             bookingResponse = "Please enter correct date"
           end
       rescue SQLite3::Exception => e
	        puts "Exception occurred"
	        puts e
       ensure
	       stm.close if stm
         updatestm.close if updatestm
	       db.close if db
       end

	     content_type :json
  	    {
  	      replies: [{ type: 'text', content: bookingResponse }],
  	      conversation: {
        		memory: modifyParams
  	      }
  	    }.to_json
  end
end

# Modify Booking (just to get the bookingID)
post '/modifyBooking' do
  # puts @params
   modifyParams = @params['conversation']['memory']

   if(modifyParams) then
     responsetext = "Give me your bookingID?"
   else
     responsetext = "Please write correct keywords."
   end

   content_type :json
     {
        replies: [{ type: 'text', content:  responsetext}],
        conversation: {
          memory: modifyParams
        }
      }.to_json
end

# Checking Booking
post '/checking' do

   if(@params['conversation']['memory']) then
     bookingParams = @params['conversation']['memory']
   else
     bookingParams = nil
   end

   bookingid = nil
   if(params['conversation']['memory']) then
    bookingid = params['conversation']['memory']['bookingid']['raw'] 
   end

   if (bookingid) then
       begin

         db = SQLite3::Database.open "ProjectDB.db"
         bookingQuery = "SELECT booking_id FROM BOOKING WHERE booking_id = '#{bookingid}'"

         stm = db.prepare(bookingQuery)
         rs = stm.execute()
         confrmBooking = rs.next

         if (confrmBooking == nil) then
    	       bookingParams = {"change"=>{"slug"=>"modify", "confidence"=>0.99, "description"=>nil}}
             responsetext = "Your Booking is not exist with above booking ID. Please check your booking ID."
         else
             responsetext = "What do you want to do, select update or cancel or show your booking? Write 'update' or 'cancel' or 'show'"
         end

       rescue SQLite3::Exception => e
         puts "Exception occurred"
         puts e
       ensure
         stm.close if stm
         db.close if db
       end
   end

    content_type :json
    {
      replies: [{ type: 'text', content: responsetext}],
       conversation: {
        memory: bookingParams
      }

    }.to_json
end

# Cancel Booking
post '/cancelbooking' do
  convsationmemory = @params['conversation']['memory']
  memorybookingID = @params['conversation']['memory']['bookingid']

  bookingid = nil
  if (convsationmemory && memorybookingID) then
    bookingid = @params['conversation']['memory']['bookingid']['raw'] 
  end
  responsetext = 'Your Booking is not cancelled. Please try again.'
  modifyParams = {}

  if bookingid.nil?
     responsetext = "Give me your bookingID?"
     modifyParams = {"change"=>{"slug"=>"modify", "confidence"=>0.99, "description"=>nil}} 
  else
      begin
  	    db = SQLite3::Database.open "ProjectDB.db"
  	    sqlDelete = "DELETE FROM BOOKING WHERE booking_id = '#{bookingid}'"

  	    stm = db.prepare(sqlDelete)
  	    rs = stm.execute()
  	    deleteBook = rs.next

  	    if (deleteBook == nil) then
  	       responsetext = "Your Booking is deleted. Thank you"
  	    else
  	       responsetext = "Your Booking is not cancelled. Please try again."
  	    end

  	  rescue SQLite3::Exception => e
  	      puts "Exception occurred"
  	      puts e
  	  ensure
  	      stm.close if stm
  	      db.close if db
  	  end
  end

  content_type :json
    {
      replies: [{ type: 'text', content: responsetext }],
      conversation: {
        memory: modifyParams
      }
    }.to_json
end

# A GENEREL FUNCTION TO EDIT DATE OR ROOMNUMBER FOR THE USER
post '/edit' do

   modifyParams = @params['conversation']['memory']
   if(modifyParams) then
     bookingid = params['conversation']['memory']['bookingid']['raw']

     if !bookingid.nil?
          begin
             db = SQLite3::Database.open "ProjectDB.db"
             bookingQuery = "SELECT booking_id FROM BOOKING WHERE booking_id = '#{bookingid}'"
             stm = db.prepare(bookingQuery)

             rs = stm.execute()
             confrmBooking = rs.next

             if (confrmBooking == nil) then
             	 modifyParams = {}
              responsetext = "Your Booking is not exist with above booking ID. Please check your booking ID."
             else
               responsetext = "What do you want to do, change the date or roomnumber? Type 'date' or 'roomnumber'"
             end

         rescue SQLite3::Exception => e
           puts "Exception occurred"
           puts e
         ensure
           stm.close if stm
           db.close if db
         end

     else
       responsetext = "Your Booking is not exist with above booking ID. Please check your booking ID."
     end
   end

   content_type :json
  {
    replies: [{ type: 'text', content: responsetext }],
    conversation: {
        memory: modifyParams
    }
  }.to_json

end

# Change Date
post '/changingDate' do

   modifyParams = @params['conversation']['memory']

   if(modifyParams) then
     bookingid = @params['conversation']['memory']['bookingid']['raw']

     if !bookingid.nil?
      responsetext = "Please give me a specific date."
     else
      responsetext = "Your Booking on this date is not exist. Please try again."
     end

   else
     responsetext = "Your Date is not correct format. Please enter a date as 'dd.mm.yyyy'."
   end

   content_type :json
    {
      replies: [{ type: 'text', content: responsetext }],
      conversation: {
        memory: modifyParams
      }
    }.to_json
end

# Change Room
post '/changingRoomnumber' do

   roomChangeParams = @params['conversation']['memory']

   if(roomChangeParams) then
     responsetext = "Which other room do you want? Please give me a specific roomnumber"
   else
     responsetext = "Please write roomnumber correct"
   end

   content_type :json
    {
      replies: [{ type: 'text', content: responsetext }],
      conversation: {
         memory: roomChangeParams
      }
    }.to_json
end

# Show booking details for bookingID
post '/show' do
  convsationmemory = @params['conversation']['memory']
  memorybookingID = @params['conversation']['memory']['bookingid']
  modifyParams = {"change"=>{"slug"=>"modify", "confidence"=>0.99, "description"=>nil}} 

  if(convsationmemory && memorybookingID) then
   bookingid = params['conversation']['memory']['bookingid']['raw']
  end
  responsetext = "Give me your bookingID?"

  if(bookingid) then
     begin
       db = SQLite3::Database.open "ProjectDB.db"
       bookingQuery = "SELECT * FROM BOOKING WHERE booking_id = '#{bookingid}'"
       stm = db.prepare(bookingQuery)

       rs = stm.execute()
       bookings = rs.next 

       if(bookings) then
         room_id = bookings[1] 
         roomQuery = "SELECT * FROM ROOMS WHERE room_id = '#{room_id}'"
         stmRoom = db.prepare(roomQuery)

         rsRoom = stmRoom.execute()
         room = rsRoom.next

         buildingNumber = nil
         if(room[1]) then
           buildingQuery = "SELECT * FROM BUILDING WHERE building_id = '#{room[1]}'"
           stmBuilding =  db.prepare(buildingQuery)
           rsBuild = stmBuilding.execute()
           building = rsBuild.next

           if(building) then
             buildingNumber = building[2]
           end
         end

         if(room) then
            responsetext = "Your Booking details: \nBuilding: '#{buildingNumber}' \nRoomnumber: '#{room[2]}' \nDate: '#{bookings[2]}'"
         end
       end

     rescue SQLite3::Exception => e
       puts "Exception occurred"
       puts e

     ensure
       stm.close if stm
       stmRoom.close if stmRoom
       stmBuilding.close if stmBuilding
       db.close if db
     end

  else
     responsetext = "Give me your bookingID?"
  end

  content_type :json
   {
     replies: [{ type: 'text', content: responsetext }],
     conversation: {
       memory: modifyParams
     }
   }.to_json

end

# Errors Handling
post '/errors' do
  puts @params
  200
end

# Test Case with all
post '/testdb' do

  begin
    db = SQLite3::Database.open "ProjectDB.db"
    stm = db.prepare "SELECT * FROM BUILDING"
    rs = stm.execute
    rs.each do |row|
      puts row.join "\s"
    end

    roomQuery =  "SELECT * FROM ROOMS"
    stmRoom = db.prepare(roomQuery)
    rsRoom = stmRoom.execute
    rsRoom.each do |row|
      puts row.join "\s"
    end

    bookingQuery = "SELECT * FROM BOOKING"
    stmBooking= db.prepare(bookingQuery)
    rsBooking= stmBooking.execute
    rsBooking.each do |row|
      puts row.join "\s"
    end

  rescue SQLite3::Exception => e
    puts "Exception occurred"
    puts e

  ensure
    stm.close if stm
    stmRoom.close if stmRoom
    stmBooking.close if stmBooking
    db.close if db
  end
  200
end
